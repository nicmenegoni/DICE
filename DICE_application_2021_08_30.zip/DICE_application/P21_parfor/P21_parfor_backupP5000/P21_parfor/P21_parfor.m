close all; clear variables; tic
%% 0) DEFINE SCAN RADIUS
userSPr=0.5;

%% 1) IMPORT FRACTURE GEOMETRY DATA
warning ('off', 'all')%warnings disabled
uiwait(msgbox('Select fracture geometry data (XLSX file) to load'));
[filename, pathname] = uigetfile({'*.xlsx', 'Select fracture geometry data (XLSX file) to load'},'Select fracture geometry data (XLSX file) to load',...
    'Z:\Menegoni\Temporanea\ROKA_files_test');% <- MODIFY the PATH

Fracdata=readtable(fullfile(pathname, filename));%read  fracture data stored
%in the previously defined XLSX file.

%% 2) IMPORT FRACTURE SET DATA
% % % % % % % % % % % % % uiwait(msgbox('Select Fracture set data (XLSX file) to load'));
% % % % % % % % % % % % % [filenameset, pathnameset] = uigetfile({'*.xlsx', 'Select Fracture set data (XLSX file) to load'},...
% % % % % % % % % % % % %     'Select Fracture set data (XLSX file) to load',...
% % % % % % % % % % % % %     pathname);
% % % % % % % % % % % % % Fracset=readtable(fullfile(pathnameset, filenameset));%read fracture set
% % % % % % % % % % % % % %stored in the previously defined XLSX file.

%% 3) DEFINE DISCONTINUITES VARIABLES FOR CALCULATION
nplane=numel(Fracdata.Dip);%number of fractures/discontinuity planes)
xyz=[Fracdata.Xcenter(:),Fracdata.Ycenter(:),Fracdata.Zcenter(:)];
Nxyz=[Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
dipdir =  Fracdata.DipDirection(:);%Fracture dip direction
dip =  Fracdata.Dip(:);%fracture dip angle
radius = Fracdata.Radius(:);
% % % % % % % % % % % % % Set = Fracset.Set;% Fracture set (defined in the imported xlsx file)
% % % % % % % % % % % % % Set(isnan(Set)) = max(Set)+1;% Definition of the random set (not defined in the imported xslx file)
% % % % % % % % % % % % % Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7
%For what concern the color it is ossible to increase the number of sets
%% 4) IMPORT AND READ  THE POINTCLOUD
uiwait(msgbox('Select PointCloud  (TXT file) to load'));
[PCfn,PCpn]=uigetfile({'*.txt', 'Select PointCloud  (TXT file) to load'},'Select PointCloud  (TXT file) to load',...
    pathname);%Import the path point cloud txt file
PC=importdata(fullfile(PCpn,PCfn));%import and read the pont cloud
ptCloud=pointCloud(PC(:,1:3));
nPC=length(PC(:,1));

%% 5) LOOP
P21=zeros(length(PC(:,1)),1);% record the p21
MTLcut=zeros(length(PC(:,1)),4);% record the statistic of the trace length only inside the circularwindow(mean, st.dev., min, max)
MTLuncut=zeros(length(PC(:,1)),4);% record the statistic of the trace length of the fracture that intersect the window (mean, st.dev., min, max)
num_idxK=zeros(length(PC(:,1)),1);%record the number of K nearest neighbour

reqKnn=requiredKNNcalc(PC(:,1:3),ptCloud,userSPr);
disp(['Time to calculate the best Knn points number ', num2str(toc/60), ' min.'])
tic
parfor ptloop= 1: nPC %define a loop foe every point of the cloud
    [idxK, ptdist] = findNearestNeighbors(ptCloud,PC(ptloop,1:3),4*reqKnn);%calculate the index of the Knn points.
    % the idxK indicates the position of the Knn points inside the PC matrix;
    % the ptdist indicates the distance of the points from the 'ptloop' one
    idxK(ptdist>userSPr)=[];
    ptdist(ptdist>userSPr)=[];
    SPpoints = PC(idxK,1:3);%define the points belonging to the scan area (based on Knn algorithm)
    num_idxK(ptloop)=length(idxK(:,1));
    %Calculating the center, normals, radius and attitude (dipdir and dip) of the scanplane
    SP_center = mean(PC(idxK,1:3));%scanplane center
    if length(idxK)>3 % if the analyzed point has three or more nearest neighbour points closer that fall in the scan radius, the code perfomr the consequent analysis
        % This if loop is necessary becasue sometimes, sparse points could
        % be present and they have a distance from the other point of the
        % pointcloud longer than the defined scan radius. Therefore, it is
        % necessary to define exclude these points from calculation
        %scanplane normals
        [V, D] = eig(cov(PC(idxK,1:3))); % calculate eigenvector 'V' and eigenvalue 'D' of thecovariance matrix 'C'
        SP_N = V(:,1)';
        SPr(ptloop,1) = max(ptdist);%radius equal to the most distance filtered Knn points (always lower than userSP)
        [sdipdir,sdip]= normal2attitude(SP_N);%attitude of the scanplane
        slopeDipdirDip(ptloop,:)=[sdipdir,sdip];
        %         if SP_N (1,3)<0
        %             overhanging(ptloop,1)=1;
        %         else
        %             overhanging(ptloop,1)=0;
        %         end
        %calculating intersection between discontinties and finite scan plane
        [p21, muL2D, stdL2D, maxL2D,minL2D,muL3D, stdL3D, maxL3D,minL3D] = P21calc(SP_center, SP_N, SPr(ptloop,1), xyz, Nxyz, radius);
        P21(ptloop)=p21;
        MTLcut(ptloop,:)=[muL2D, stdL2D, maxL2D,minL2D];%mean, st.dev., max and min values of the 'cutted'trace length (only the segment within the circular window)
        MTLuncut(ptloop,:)= [muL3D, stdL3D, maxL3D,minL3D];%mean, st.dev., max and min values of dimension of the fractures that intersect the circular window
    end
end
disp(['->Exporting_results_at_= ',num2str(toc/60,'%.1f'), '(min)'])
mkdir (pathname,'P21pointclouds_resuls')
clear fid
fid = fopen(fullfile([pathname,'P21pointclouds_resuls'],['P21_r_',num2str(userSPr,'%.1f'),'.txt']),'wt');
fprintf(fid, 'X Y Z R G B P21 MTL2D TL2Dstd TL2Dmax TL2Dmin MFL3D FL3Dstd FL3Dmax FL3Dmin DipDir Dip Scanradius \n');
fprintf(fid, '%.6f %.6f %.6f %3.0f %3.0f %3.0f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f %.3f \n', ...
    [PC(:,1),PC(:,2),PC(:,3),...
    PC(:,4),PC(:,5),PC(:,6),P21(:),...
    MTLcut(:,1),MTLcut(:,2),MTLcut(:,3),MTLcut(:,4),...
    MTLuncut(:,1),MTLuncut(:,2),MTLuncut(:,3),MTLuncut(:,4)...
    slopeDipdirDip(:,1),slopeDipdirDip(:,2), SPr(:)]');
fclose(fid);
disp('End of point cloud exporting process')