clear all
close all

[fnPC, pnPC] = uigetfile({'*.txt', 'Select a pointcloud in txt'},'Select a pointcloud');
PC=importdata(fullfile(pnPC, fnPC));
CWr = 1;

Ready1 = [];button1=1;answer1 = 'y';
while (answer1 == 'y' & isempty(Ready1) & button1==1)
    






