%% P21 calculation using a Circular Window (CW)
close all
clear all
%% DATESET READING
%1)define path and file where fracture data are stored
[fn, pn] = uigetfile({'*.xlsx', 'Select a XLSX fracture geometry file'},'Select a fracture geometry file');
Fracdata=readtable(fullfile(pn, fn));
nplane=numel(Fracdata.Dip); %number of rows (= number of plane).
%2)define path and file where fracture set definition data are stored
[fnset, pnset] = uigetfile({'*.xlsx', 'Select a XLSX file'},'mytitle',...
    pn);
Fracset=readtable(fullfile(pnset, fnset));
%3)Read fracture geometry and set defintion data
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
radius = Fracdata.Radius(:);
Set = Fracset.Set;
Set(isnan(Set)) = max(Set)+1;
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7
%4)load the point cloud and plot it
[fnPC, pnPC] = uigetfile({'*.txt', 'Select a pointcloud in txt'},'Select a pointcloud',pn);
PC=importdata(fullfile(pnPC, fnPC));
figure(1); 
%pcshow(PC(:,1:3)); 
pcshow(PC(:,1:3),PC(:,4:6)/255);
CWr = 1;
CWradius_range=CWr/10;
%% CALCULATION
[CWplane, maxCW_dist, minCW_dist] = selectCW(PC,CWr); %select the circular window
CWxyz0=CWplane(4:6);CWNxyz=CWplane(7:9); %define its center and normal vector

CWxyz_range= CWxyzRange(CWxyz0, CWNxyz, CWradius_range, minCW_dist, maxCW_dist);%create sevral CWs to sample all the 3D space
%5)Plot Circular Window
L=zeros(nplane,length(CWxyz_range));
l=zeros(nplane,length(CWxyz_range));
m_mauldon=zeros(nplane,length(CWxyz_range));
m_mauldon=zeros(nplane,length(CWxyz_range));
figure

thetaCW=0:0.1:2*pi; vCW=null(CWNxyz);
pointsCW0=repmat(CWxyz0',1,size(thetaCW,2))+CWr*(vCW(:,1)*cos(thetaCW)+...
    vCW(:,2)*sin(thetaCW));

fill3(pointsCW0(1,:),pointsCW0(2,:),pointsCW0(3,:),'r', 'FaceAlpha', 1);%plot disc of circular window
xlabel('x-axis (East)');ylabel('y-axis (Nord)');zlabel('z-axis (Elev)')
hold on; grid on; axis on; axis equal
for i = 1 : nplane
    theta=0:0.1:2*pi; %Setting the spacing in which coordinate of the discontinuity disc are calculated
    v=null(Nxyz(i,:));% calculate vectors needed to plot the discs
    points=repmat(xyz(i,:)',1,size(theta,2))+radius(i)*(v(:,1)*cos(theta)+v(:,2)*sin(theta));%calculate points coordinate of the discs
    
    % Change name to the coordinate in a better and more resonable name
    X=points(1,:)';
    Y=points(2,:)';
    Z=points(3,:)';
    fill3(points(1,:),points(2,:),points(3,:),'b', 'FaceAlpha', 0.5);%Plot 3D disc for each plane
end
f1=figure;
for r = 1 : length(CWxyz_range)
    
    CWxyz = CWxyz_range(r,:);
    thetaCW=0:0.1:2*pi; vCW=null(CWNxyz);
    pointsCW=repmat(CWxyz',1,size(thetaCW,2))+CWr*(vCW(:,1)*cos(thetaCW)+...
        vCW(:,2)*sin(thetaCW));
    XCW=pointsCW(1,:)';YCW=pointsCW(2,:)';ZCW=pointsCW(3,:)';
    hold on;
    subplot(ceil(length(CWxyz_range)/3),3,r)
    fill3(pointsCW(1,:),pointsCW(2,:),pointsCW(3,:),'b', 'FaceAlpha', 0.5);%plot disc of circular window
    xlabel('x-axis (East)');ylabel('y-axis (Nord)');zlabel('z-axis (Elev)')
    hold on; grid on; axis on; axis equal
    title(['CW range : ',num2str(CWxyz - CWxyz0)])
    
    if CWplane(2) < 180
        azView = CWplane(2)-180;
    elseif CWplane(2) > 180
        azView = 360-CWplane(2)+180;
    elseif CWplane(2) == 180
        azView =0;
    elseif CWplane(2) == 0 || CWplane(2) == 360
        azView = 180;
    end
    elView=90-CWplane(1);
    view(azView,elView)
    
    
    [L(:,r),l(:,r),m_mauldon(:,r),n_mauldon(:,r),countCWDisc_inter] =intCWdisc(CWxyz, CWNxyz, CWr, xyz, Nxyz, radius, Set, f1);
    
end
[mu_set,mu,I,rho,P21,MTL2D,stdevL2D,max_L_uncut,min_L_uncut,max_l_cut,min_l_cut] = CWstatistic(l,L,Set,m_mauldon,n_mauldon,CWr,countCWDisc_inter)