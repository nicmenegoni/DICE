function [maxMax, minMax, maxMin,minMin]=boundingBoxPlane(SPpoints)
tic
% number of points
ell = inertiaEllipsoid(SPpoints);
n = size(SPpoints, 1);

% compute centroid
SPcenter = mean(SPpoints);

% compute the covariance matrix
covPts = cov(SPpoints)/n;
[U, S] = svd(covPts);
[V, D] = eig(cov(SPpoints));
radii = sqrt(5) * sqrt(diag(S)*n)';
maxdir=U(:,1)';%direction of maximum axis
maxmagn=radii(1);%magnitude of max semiaxis
mindir=U(:,2)';%direction minimum axes
minmagn=radii(2);%magn. of min axis
maxvector=maxmagn*maxdir;
minvector=minmagn*mindir;
SP_N = V(:,1)';
if SP_N(1,3)<0 %if normal is oriented downward
    SP_N(1,1)=-SP_N(1,1);
    SP_N(1,2)=-SP_N(1,2);
    SP_N(1,3)=-SP_N(1,3);
end
out=convhull(SPpoints);
extremes=SPpoints(out,:);
SPpointPlaneMaxMagn=createPlane(SPcenter, maxvector);
SPpointPlaneMinMagn=createPlane(SPcenter, minvector);
SPPlane=createPlane(SPcenter,SP_N);
for i=1:length(extremes)
PT(i,:) = projPointOnPlane(extremes(i,:), SPPlane);
end

for i=1:length(PT)
    
    PTdistanzaMaxMagn(i)=distancePointPlane(PT(i,:), SPpointPlaneMaxMagn);
    
    PTdistanzaMinMagn(i)=distancePointPlane(PT(i,:), SPpointPlaneMinMagn);
    
end
[maxMax,ImaxMax]=max(PTdistanzaMaxMagn);
[minMax, IminMax]=min(PTdistanzaMaxMagn);
[maxMin,ImaxMin]=max(PTdistanzaMinMagn);
[minMin, IminMin]=min(PTdistanzaMinMagn);
toc
end