close all
clear all
%% 1) LOAD & READ XLSX CIRCULAR FRACTURE DATA
%  Select CSV file containing all plane
if ismac %For OSX operative system
    [fn, pn] = uigetfile({'*.xlsx', 'Select a XLSX fracture geometry file'},'Select a fracture geometry file');% <- MODIFY the PATH
elseif ispc % For WINDOWS operative system
    [fn, pn] = uigetfile({'*.xlsx', 'Select a XLSX fracture geometry file'},'Select a fracture geometry file');% <- MODIFY the PATH
end
Fracdata=readtable(fullfile(pn, fn));
nplane=numel(Fracdata.Dip); %number of rows (= number of plane)
%% 2) LOAD & READ XLSX SET BELONGING DATA
[fneset, pnset] = uigetfile({'*.xlsx', 'Select a XLSX fracture set file'},'mytitle',...
    pn);
Fracset=readtable(fullfile(pnset, fnset));
nplane=numel(Fracset.Set); %number of rows (= number of plane)
%% LOAD & READ the Pointcloud file
[fnPC, pnPC] = uigetfile({'*.txt', 'Select a pointcloud in txt'},'Select a pointcloud',...
    pn);
PC=importdata(fullfile(pnPC, fnPC));
%% 4) DEFINE VARIABLES FOR CALCULATION
dipdir =  Fracdata.DipDirection(:);%Dip direction
dip =  Fracdata.Dip(:);%Dip angle
xyz = [Fracdata.Xcenter(:), Fracdata.Ycenter(:), Fracdata.Zcenter(:)];
Nxyz = [Fracdata.Nx(:),Fracdata.Ny(:),Fracdata.Nz(:)];
radius = Fracdata.Radius(:);
Set = Fracset.Set;
Set(isnan(Set)) = max(Set)+1;
nplane=n;
Color = {'k','b','r','g','y',[.5 .6 .7],[.8 .2 .6]};% define color for set from 1 to 7
SVxyz=[1,1,1];% scan volume (sphere) center
SVr=1.5;% scan volume (sphere) radius
SV=[Sxyz,Sr];% scan volume express as required yby the function intersectPlaneSphere
%%P32 calculation
xyz = xyz(i);
%1) calculate intersection between the scan volume and the fracture
%'infinite plane'
sumarea=0;
sumareaset=zeroz(1,max(Set));
for j=1:length(PC(:,1))
    clear P32
    clear P32set
    sumarea=0;
    sumareaset=zeroz(1,max(Set));
for i=1 : nplane
    clear PLANEtemp CIRCtemp IntArea
PLANEtemp = [xyz(i), Nxyz(i)];
CIRCtemp = intPlaneSphere(PLANEtemp, SV);
IntArea = intCircCirc(CIRCtemp(1:3),CIRCtemp(4), SVxyz, SVr);
if IntArea ~= NaN
sumarea = sumarea + IntArea;
sumareaset(1,Set(i)) = sumareaset(1,Set(i)) + IntArea;
%andrebbe fatto per ogni set
end
P32 = sumarea / ((4/3)*pi*SVr^2); %total P32 (all sets together)
P32set = sumareaset / ((4/3)*pi*SVr^2);%P32 specific for each set)
end

fid = fopen('P32_pointcloud.txt','wt');
for ii = 1:size(A,1)
    fprintf(fid,'%g\t',A(ii,:));
    fprintf(fid,'\n');
end
fclose(fid)

end

















