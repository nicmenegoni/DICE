function c_Val = f_ValGrCode(grCode,m_GrCode,c_ValAsoc)
c_Val = c_ValAsoc(m_GrCode==grCode);
end